import UIKit

enum PromiseState {
    case Pending, Fulfilled, Rejected
    var isSettled: Bool {
        return self != .Pending
    }
}

extension NSError {
    convenience init(string: String) {
        self.init(domain: string, code: 0, userInfo: nil)
    }
}

class Promise<T> {
    
    typealias Data = T
    typealias Error = NSError
    
    typealias ResolveCallback = Data -> ()
    
    typealias RejectCallback = Error -> ()
    typealias FinallyCallback = (Data?, Error?) -> ()
    
    typealias ResolveFunction = Data -> ()
    typealias RejectFunction = Error -> ()
    
    var resolveCallbacks: [ResolveCallback]! = []
    var rejectCallbacks: [RejectCallback]! = []
    var status: PromiseState = .Pending
    var data: Data?
    var error: Error?
    
    init() { }
    
    init(_ executor: ResolveFunction -> ()) {
        executor(resolve)
    }
    
    init(_ executor: (ResolveFunction, RejectFunction) -> ()) {
        executor(resolve, reject)
    }
    
    func then(resolveCallback: ResolveCallback?, _ rejectCallback: RejectCallback?) {
        
        if let callback = resolveCallback {
            switch status {
            case .Pending:
                resolveCallbacks.append(callback)
            case .Fulfilled:
                callback(data!)
            default: break
            }
        }
        
        if let callback = rejectCallback {
            switch status {
            case .Pending:
                rejectCallbacks.append(callback)
            case .Rejected:
                callback(error!)
            default: break
            }
        }
    }
    
    func then(resolveCallback: ResolveCallback) -> SelfPromise {
        then(resolveCallback, nil);
        return self
    }
    func `catch`(rejectCallback: RejectCallback) {
        then(nil, rejectCallback)
    }
    func finally(callback: FinallyCallback) {
        then({ data in
            callback(data, nil)
        }, { error in
            callback(nil, error)
        })
    }
    
    private func clearCallbacks() {
        resolveCallbacks = nil
        rejectCallbacks = nil
    }
    
    lazy var resolve: ResolveFunction = { data in
        if self.status.isSettled { return }
        
        self.status = .Fulfilled
        
        self.data = data
        
        for callback in self.resolveCallbacks {
            callback(data)
        }
        self.clearCallbacks()
    }
    lazy var reject: RejectFunction = { error in
        if self.status.isSettled { return }
        
        self.status = .Rejected
        
        self.error = error
        
        for callback in self.rejectCallbacks {
            callback(error)
        }
        self.clearCallbacks()
    }
    
    typealias SelfPromise = Promise<T>
    
    static func resolve(data: Data) -> SelfPromise {
        return SelfPromise { resolve in
            resolve(data)
        }
    }
    static func reject(error: Error) -> SelfPromise {
        return SelfPromise { resolve, reject in
            reject(error)
        }
    }
    
    static func race(promises: Promise<Data>...) -> Promise<Data> {
        return Promise<Data> { resolve, reject in
            for promise in promises {
                promise.then(resolve, reject)
            }
        }
    }
}
