//
//  Util.swift
//  DeLaval MyFarm Beta
//
//  Created by Jöran Rapp on 31/07/15.
//  Copyright (c) 2015 DeLaval. All rights reserved.
//

import Foundation
import WebKit

extension WKWebView {
    func invalidateVisibleRect() {
        let contentOffset = scrollView.contentOffset
        scrollView.setContentOffset(CGPoint(x: contentOffset.x, y: contentOffset.y), animated: true)
    }
    func loadLocalFile(name: String, baseUrl: NSURL) {
        let path = NSBundle.mainBundle().pathForResource(name, ofType: "html")!
        let text = try! String(contentsOfFile: path, encoding: NSUTF8StringEncoding)
        self.loadHTMLString(text, baseURL: baseUrl)
    }
}

extension String {
    static func urlEncode(urlString: String) -> String {
        return urlString.stringByAddingPercentEncodingWithAllowedCharacters(.URLHostAllowedCharacterSet())!
    }
    func limitTo(limit: Int) -> String {
        return self.characters.count < limit ? self : substringToIndex(startIndex.advancedBy(limit)) +  "..."
    }
}

extension NSURL {
    var isValidForWebView: Bool {
        return !scheme.isEmpty && host != nil && !host!.isEmpty
    }
}

func buildUrl(base: String, path: String?, search: [String: String]? = nil, hash: String? = nil, hashUrl: Bool = true) -> String {
    var url = base
    if hashUrl {
        url += "#/"
    } else {
        url += "/"
    }
    
    if path != nil {
        url += path!
    }
    if search != nil {
        var pairs: [String] = []
        for (key, value) in search! {
            pairs.append("\(key)=\(value)")
        }
        url += "?" + String.urlEncode(pairs.joinWithSeparator("&"))
    }
    if hash != nil {
        url += "#" + String.urlEncode(hash!)
    }
    return url
    
}

func timeout(delayInSeconds: Double) -> Promise<Void> {
    let delayTime = Int64(delayInSeconds * Double(NSEC_PER_SEC))
    return Promise { resolve, _ in
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delayTime),
                dispatch_get_main_queue(), resolve)
    }
}