//
//  ViewController.swift
//  VGY Schema
//
//  Created by Jöran Rapp on 02/03/16.
//  Copyright © 2016 John Rapp & Simon Halvdansson. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKUIDelegate, WKNavigationDelegate, JavascriptInterfaceDelegate {
    
    var webView: WKWebView!
    
    let javascriptInterface = JavascriptInterface()
    
    let serverUrl = "http://vgy.rocks/schema"
    
    let timeoutInterval = 20.0
    
    var requestFinished: Promise<Void>!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupStatusbar()
        
        setupWebView()
        
        do {
            let reachability = try Reachability.reachabilityForInternetConnection()
            if(reachability.isReachable()) {
                loadWebApplication()
            } else {
                loadErrorPage()
            }
        } catch {
            loadWebApplication()
        }
        
    }
    func setupWebView() {
        let userContentController = WKUserContentController()
        userContentController.addScriptMessageHandler(javascriptInterface, name: "app")
        javascriptInterface.delegate = self
        
        let config = WKWebViewConfiguration()
        config.userContentController = userContentController
        
        webView = WKWebView(frame: self.view.frame, configuration: config)
        self.view.addSubview(webView)
        layoutWebView()
        
        javascriptInterface.webView = self.webView
        
        webView.UIDelegate = self
        webView.navigationDelegate = self
    }
    
    func loadWebApplication() {
        let url = NSURL(string: serverUrl)!
        let request = NSURLRequest(URL: url, cachePolicy: .UseProtocolCachePolicy, timeoutInterval: timeoutInterval)
        
        webView.loadRequest(request)
        print("request sent \(url)".limitTo(80))
        startLoading()
        
    }
    func loadErrorPage() {
        requestFinished = Promise()
        let url = NSURL(string: buildUrl("http://localhost", path: "error", search: nil, hash: serverUrl, hashUrl: false))!
        
        webView.loadLocalFile("error", baseUrl: url)
    }
    
    func startLoading() {
        requestFinished = Promise()
        
        //Add a manual timeout, since the browser timeout is not always fired (for an unknown reason)
        Promise<Void>.race(timeout(timeoutInterval), requestFinished).finally { _ in
            
            if !self.requestFinished.status.isSettled {
                print("timeout manually fired")
                self.webView.stopLoading()
                self.loadErrorPage()
            }
            
        }
        
    }
    
    override func willRotateToInterfaceOrientation(toInterfaceOrientation: UIInterfaceOrientation, duration: NSTimeInterval) {
        UIView.animateWithDuration(0.15) {
            self.webView.alpha = 0
        }
    }
    
    override func didRotateFromInterfaceOrientation(fromInterfaceOrientation: UIInterfaceOrientation) {
        
        let orientation = UIApplication.sharedApplication().statusBarOrientation
        if UIInterfaceOrientationIsLandscape(orientation) {
            //Remove top margin in landscape
            self.layoutWebView(0)
        } else {
            self.layoutWebView()
        }
        UIView.animateWithDuration(0.3) {
            self.webView.alpha = 1
        }
    }
    
    
    func setupStatusbar() {
        view.backgroundColor = UIColor(red: 17 / 255, green: 23 / 255, blue: 26 / 255, alpha: 1)
        
        self.setNeedsStatusBarAppearanceUpdate()
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return .LightContent;
    }
    
    
    func webView(webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: () -> Void) {
        print("Alert: \(message)")
        completionHandler()
    }
    
    func layoutWebView(topMargin: CGFloat = 20.0) {
        let frame = CGRect(x: 0, y: topMargin, width: view.frame.width, height: view.frame.height - topMargin)
        //let frame = CGRect(x: 100, y: 100, width: 100, height: 100)
        webView.frame = frame
    }
    
    func reload() {
        loadWebApplication()
    }
    
    func captureScreen() {
        
    }
    
    func webView(webView: WKWebView, didCommitNavigation navigation: WKNavigation!) {
        
        print("commited navigation")
        javascriptInterface.clearCallbacks();
    }
    func webView(webView: WKWebView, didFinishNavigation navigation: WKNavigation!) {
        print("finished navigation")
        requestFinished.resolve()
    }
    func webView(webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("started prov. navigation")
    }
    func webView(webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: NSError) {
        print("failed prov. navigation: \(error.localizedDescription)")
        loadErrorPage()
        requestFinished.reject(error)
    }
    func webView(webView: WKWebView, didFailNavigation navigation: WKNavigation!, withError error: NSError) {
        print("failed navigation: \(error.localizedDescription)")
        requestFinished.reject(error)
        switch error.code {
        case NSURLErrorCancelled:
            print("request CANCELLED")
        default: break
        }
    }
    
    func webView(webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        
        print("recieved redirect")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

