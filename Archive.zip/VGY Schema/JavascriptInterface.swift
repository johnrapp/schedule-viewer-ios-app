//
//  JavascriptInterface.swift
//  DeLaval MyFarm Beta
//
//  Created by Jöran Rapp on 10/07/15.
//  Copyright (c) 2015 DeLaval. All rights reserved.
//

import UIKit
import WebKit

protocol JavascriptInterfaceDelegate {
    func reload()
    func captureScreen()
}

class JavascriptInterface: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
    struct JavascriptFunction {
        let invoke: String
        
        init(_ invoke: String) {
            self.invoke = invoke
        }
        
        func call(argument: String) -> String {
            return invoke.stringByReplacingOccurrencesOfString("{{argument}}", withString: argument, options: NSStringCompareOptions(), range: nil)
        }
    }
    
    var delegate: JavascriptInterfaceDelegate!
    weak var webView: WKWebView!
    
    var javascriptCallbacks: [String: Promise<JavascriptFunction>] = [:]
    
    func callMethod(method: String, argument: String) {
        var promise = javascriptCallbacks[method]
        if promise == nil {
            promise = Promise<JavascriptFunction>()
            javascriptCallbacks[method] = promise
        }
        promise!.then { function -> Void in
            print("-> \(method): \(argument)".limitTo(80))
            self.evaluateJavascriptFunction(function, argument: argument)
        }
    }
    
    func clearCallbacks() {
        javascriptCallbacks.removeAll(keepCapacity: true)
        print("** Callbacks cleared **")
    }
    
    private func handleJavascriptMessage(method method: String, argument: AnyObject?) {
        print("<- \(method): \(argument)".limitTo(80))
        
        switch method {
        case "registerCallback":
            let arg = argument! as! NSDictionary
            registerCallback(method: arg["method"] as! String, function: JavascriptFunction(arg["invoke"] as! String))
        case "reload":
            delegate!.reload()
        case "forceUpdate":
            print("Force update!")
        default: break
        }
    }
    
    private func registerCallback(method method: String, function: JavascriptFunction) {
        if let promise = javascriptCallbacks[method] {
            promise.resolve(function)
        } else {
            javascriptCallbacks[method] = Promise<JavascriptFunction>.resolve(function)
        }
        
    }
    
    func evaluateJavascriptFunction(function: JavascriptFunction, argument: String) {
        webView.evaluateJavaScript(function.call(argument), completionHandler: nil)
    }
    
    func userContentController(userContentController: WKUserContentController, didReceiveScriptMessage message: WKScriptMessage) {
        
        if let method = message.body["method"] as? String {
            let argument = message.body["argument"]
            
            handleJavascriptMessage(method: method, argument: argument)
        }
    }
}
